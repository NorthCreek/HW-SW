/*******************************************************
 * main.cpp — LEDs demo for single HLS IP core (alarm_ip)
 *
 * - Only alarm_ip (AXI4-Lite) + LED GPIO
 * - Software generates simple test data:
 *     S1, S2 ∈ [0..5], 81 camera pixels ∈ [0..9]
 * - Every 3–4 loops we force a “strong intruder”
 * - Own tiny PRNG: randseed() + rand32() (no std::rand)
 *******************************************************/

#include "xparameters.h"
#include "xstatus.h"
#include "xgpio.h"
#include "sleep.h"          // usleep()

#include "xalarm_ip.h"
#include "xalarm_ip_hw.h"   // register offsets for alarm_ip

/* -------- Device IDs (match xparameters.h) -------- */
#ifndef LEDS_GPIO_DEVICE_ID
  #ifdef XPAR_AXI_GPIO_LEDS_DEVICE_ID
    #define LEDS_GPIO_DEVICE_ID XPAR_AXI_GPIO_LEDS_DEVICE_ID
  #elif defined(XPAR_AXI_GPIO_0_DEVICE_ID)
    #define LEDS_GPIO_DEVICE_ID XPAR_GPIO_0_DEVICE_ID
  #elif defined(XPAR_GPIO_0_DEVICE_ID)
    #define LEDS_GPIO_DEVICE_ID XPAR_GPIO_0_DEVICE_ID
  #else
    #error "Set LEDS_GPIO_DEVICE_ID to your AXI GPIO instance ID"
  #endif
#endif

#ifndef ALARM_IP_DEVICE_ID
  #define ALARM_IP_DEVICE_ID XPAR_ALARM_IP_0_DEVICE_ID
#endif

/* ---------------- Instances ---------------- */
static XGpio     GpioLeds;
static XAlarm_ip IpAlarm;

/* ===================================================
 *  1) Tiny PRNG: randseed() + rand32()
 * ===================================================*/

/* Global seed for our PRNG */
static u32 g_seed = 1u;

/* Set seed (use 1 as fallback if user gives 0) */
static void randseed(u32 seed)
{
    g_seed = (seed == 0u) ? 1u : seed;
}

/* Very simple linear congruential generator (LCG)
 * new_seed = (a * old_seed + c) mod 2^32
 *   a = 1103515245, c = 12345 (classic constants)
 */
static inline u32 rand32()
{
    g_seed = g_seed * 1103515245u + 12345u;
    return g_seed;
}

/* Random integer in [0 .. max_value] */
static inline u32 random_in_range(u32 max_value)
{
    return (max_value == 0u) ? 0u : (rand32() % (max_value + 1u));
}

/* ===================================================
 *  2) alarm_ip helper functions
 * ===================================================*/

/* Run alarm_ip once and wait for ap_done */
static void RunAndWait_alarm(XAlarm_ip *p)
{
    XAlarm_ip_Start(p);
    while (!XAlarm_ip_IsDone(p)) {
        // busy wait – simple PS/PL sync
    }
}

/* Decode packed 32-bit return from alarm_ip:
 * [31:16] = intr_sum, [2] = alarm_on, [1:0] = state
 */
static inline void decode_alarm_return(u32 ret, u8 *state, u8 *alarm_on, u16 *intr_sum)
{
    *state    = static_cast<u8>(ret & 0x3u);
    *alarm_on = static_cast<u8>((ret >> 2) & 0x1u);
    *intr_sum = static_cast<u16>(ret >> 16);
}

/* Write full camera image C[0..80] (81 pixels) via AXI4-Lite */
static void load_camera_image(XAlarm_ip *p, const u32 cam[81])
{
    u32 base = p->Ctrl_BaseAddress;
    for (int i = 0; i < 81; ++i) {
        XAlarm_ip_WriteReg(
            base,
            XALARM_IP_CTRL_ADDR_C_BASE + 4 * i,  // 4 bytes per word
            cam[i]
        );
    }
}

/* Scalar arguments: S1, S2, threshold */
static inline void alarm_set_s1(XAlarm_ip *p, u32 v)
{
    XAlarm_ip_WriteReg(
        p->Ctrl_BaseAddress,
        XALARM_IP_CTRL_ADDR_S1_DATA,
        v
    );
}

static inline void alarm_set_s2(XAlarm_ip *p, u32 v)
{
    XAlarm_ip_WriteReg(
        p->Ctrl_BaseAddress,
        XALARM_IP_CTRL_ADDR_S2_DATA,
        v
    );
}

static inline void alarm_set_threshold(XAlarm_ip *p, u32 v)
{
    XAlarm_ip_WriteReg(
        p->Ctrl_BaseAddress,
        XALARM_IP_CTRL_ADDR_THRESHOLD_DATA,
        v
    );
}

/* ===================================================
 *  3) LED feedback
 * ===================================================*/
static void update_leds(u8 state, u8 alarm_on)
{
    if (state == 2u || alarm_on) {
        // Intruder / ALARMED
        XGpio_DiscreteWrite(&GpioLeds, 1, 0b1110);
        usleep(500000);   // 0.5 s
    } else if (state == 1u) {
        // ACTIVE but no intrusion
        XGpio_DiscreteWrite(&GpioLeds, 1, 0b0001);
        usleep(250000);   // 0.25 s
    } else {
        // INACTIVE
        XGpio_DiscreteWrite(&GpioLeds, 1, 0b0100);
        usleep(250000);
    }
}

/* ===================================================
 *  4) Init + soft reset
 * ===================================================*/
static int init_all()
{
    int s;

    // Init LEDs GPIO
    s = XGpio_Initialize(&GpioLeds, LEDS_GPIO_DEVICE_ID);
    if (s != XST_SUCCESS) return s;
    XGpio_SetDataDirection(&GpioLeds, 1, 0x00);   // all outputs
    XGpio_DiscreteWrite(&GpioLeds, 1, 0x00);

    // Init alarm_ip driver
    if (XAlarm_ip_Initialize(&IpAlarm, ALARM_IP_DEVICE_ID) != XST_SUCCESS)
        return XST_FAILURE;

    // Soft reset internal state in PL (state, alarm_on, alarm_ms)
    XAlarm_ip_Set_reset(&IpAlarm, 1);
    XAlarm_ip_Set_do_sample(&IpAlarm, 0);
    RunAndWait_alarm(&IpAlarm);
    XAlarm_ip_Set_reset(&IpAlarm, 0);

    return XST_SUCCESS;
}

/* ===================================================
 *  5) Main
 * ===================================================*/
int main()
{
    if (init_all() != XST_SUCCESS) {
        // init failure -> fast blink
        for (;;) {
            XGpio_DiscreteWrite(&GpioLeds, 1, 0b1111);
            usleep(200000);
            XGpio_DiscreteWrite(&GpioLeds, 1, 0x00);
            usleep(200000);
        }
    }

    // Seed our own PRNG once (repeatable tests)
    randseed(1u);

    // ---- Arm system once with valid PIN (even) ----
    XAlarm_ip_Set_pin_code(&IpAlarm, 2);      // valid PIN: even
    XAlarm_ip_Set_enter_pin(&IpAlarm, 1);     // user presses button
    XAlarm_ip_Set_do_sample(&IpAlarm, 0);
    RunAndWait_alarm(&IpAlarm);
    XAlarm_ip_Set_enter_pin(&IpAlarm, 0);     // release button

    // Threshold fixed to 1900, as in spec
    alarm_set_threshold(&IpAlarm, 1900u);

    // Intruder scheduler: every 3 or 4 loop iterations
    int cycles_to_intr = 3 + static_cast<int>(random_in_range(1u));  // 3 or 4

    for (;;) {
        // Decide if this loop should inject a strong intrusion
        int inject = 0;
        if (--cycles_to_intr <= 0) {
            inject = 1;
            cycles_to_intr = 3 + static_cast<int>(random_in_range(1u));   // again 3 or 4
        }

        // ===== RUNNING (status) =====
        XGpio_DiscreteWrite(&GpioLeds, 1, 0b0011);  // running
        usleep(200000);                             // 200 ms

        // ---- Build simple sensor + camera test data ----
        u32 S1 = random_in_range(5u);   // 0..5
        u32 S2 = random_in_range(5u);   // 0..5
        u32 cam[81];

        u32 base_pix = random_in_range(9u);  // 0..9
        for (int i = 0; i < 81; ++i) {
            cam[i] = base_pix;
        }

        if (inject) {
            // Strong intrusion: max sensors and bright pixels
            S1 = 5;
            S2 = 5;
            for (int i = 0; i < 81; ++i) {
                cam[i] = 9;
            }
        }

        // Write camera + sensors to alarm_ip
        load_camera_image(&IpAlarm, cam);
        alarm_set_s1(&IpAlarm, S1);
        alarm_set_s2(&IpAlarm, S2);

        // One sample step = 120 ms in the model
        XAlarm_ip_Set_do_sample(&IpAlarm, 1);
        RunAndWait_alarm(&IpAlarm);
        XAlarm_ip_Set_do_sample(&IpAlarm, 0);

        // Read result from IP
        u32 alarm_ret = XAlarm_ip_Get_return(&IpAlarm);
        u8  state    = 0;
        u8  alarm_on = 0;
        u16 intr_sum = 0;
        decode_alarm_return(alarm_ret, &state, &alarm_on, &intr_sum);

        // LED feedback in one place (clear and testable)
        update_leds(state, alarm_on);

        // Small pause between cycles
        usleep(200000);
    }
}


